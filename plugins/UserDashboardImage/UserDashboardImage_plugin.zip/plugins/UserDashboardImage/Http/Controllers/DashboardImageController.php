<?php

namespace plugins\UserDashboardImage\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use App\Models\User; // Assuming your User model is in App\Models

class DashboardImageController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'dashboard_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $user = Auth::user();

        if ($request->hasFile('dashboard_image')) {
            // Delete old image if exists
            if ($user->dashboard_image_path && Storage::disk('public')->exists($user->dashboard_image_path)) {
                Storage::disk('public')->delete($user->dashboard_image_path);
            }

            $image = $request->file('dashboard_image');
            $imageName = time() . '_' . $image->getClientOriginalName();
            // Store in 'public/dashboard_images/user_id/image_name.ext'
            $path = $image->storeAs('dashboard_images/' . $user->id, $imageName, 'public');

            // Update user's dashboard_image_path
            // Assuming your User model is App\Models\User and you have a 'dashboard_image_path' column
            $userToUpdate = User::find($user->id);
            if ($userToUpdate) {
                $userToUpdate->dashboard_image_path = $path;
                $userToUpdate->save();
            }
            
            return back()->with('success', 'Imagem do dashboard atualizada com sucesso!')->with('dashboard_image_path', $path);
        }

        return back()->with('error', 'Falha no upload da imagem.');
    }
}

