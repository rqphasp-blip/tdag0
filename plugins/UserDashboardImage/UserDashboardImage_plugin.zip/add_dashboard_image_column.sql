ALTER TABLE users ADD COLUMN dashboard_image_path VARCHAR(255) NULL DEFAULT NULL;

-- Nota: Se sua tabela de usuários não se chamar 'users', ajuste o nome da tabela no comando acima.
