<?php return array (
  'user-table' => 'App\\Http\\Livewire\\UserTable',
);