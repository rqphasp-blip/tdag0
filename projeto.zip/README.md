
  _    _                 _                   _                   _      _       _     _____ _             _    
 | |  | |               | |                 | |                 | |    (_)     | |   / ____| |           | |   
 | |__| | _____      __ | |_ ___    ___  ___| |_   _   _ _ __   | |     _ _ __ | | _| (___ | |_ __ _  ___| | __
 |  __  |/ _ \ \ /\ / / | __/ _ \  / __|/ _ \ __| | | | | '_ \  | |    | | '_ \| |/ /\___ \| __/ _` |/ __| |/ /
 | |  | | (_) \ V  V /  | || (_) | \__ \  __/ |_  | |_| | |_) | | |____| | | | |   < ____) | || (_| | (__|   < 
 |_|  |_|\___/ \_/\_/    \__\___/  |___/\___|\__|  \__,_| .__/  |______|_|_| |_|_|\_\_____/ \__\__,_|\___|_|\_\
                                                        | |                                                    
                                                        |_|                                                    
                                                                       
To set up LinkStack, download the latest release from GitHub and simply put the contents of the folder 'linkstack' in the root directory of your website.

You can find more information on how to set up a reverse proxy on docs.linkstack.org.

That's it! No coding, no command line setup, just plug and play.

Now access your install of LinkStack with 'your-domain-name.com'.