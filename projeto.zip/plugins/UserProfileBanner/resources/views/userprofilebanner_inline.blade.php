<?php
// Arquivo de view inline para ser usado pelo ServiceProvider
// Coloque este arquivo em resources/views/userprofilebanner_inline.blade.php
?>
{!! $content !!}
