<?php

use Illuminate\Support\Facades\Route;

Route::get('meu-plugin', function () {
    return 'Olá do Meu Plugin!';
});